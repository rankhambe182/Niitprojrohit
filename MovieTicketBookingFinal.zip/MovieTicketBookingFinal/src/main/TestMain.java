package main;

import daoimpl.UserDaoImpl;
import java.util.List;
import model.User;

/**
 *
 * @author hamee_000
 */
public class TestMain {
    public static void main(String[] args) {
        UserDaoImpl udi = new UserDaoImpl();
      
    }
}
