package daoimpl;

import dao.UserDao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.User;

public class UserDaoImpl implements UserDao{

    List<User> ul;
    User u;
    Connection con;
    PreparedStatement ps;
    //int lid;
    public UserDaoImpl() {
        //connecting program to database
        try {
            Class.forName("org.h2.Driver");
            con = DriverManager.getConnection("jdbc:h2:~/test", "sa", "pass");
            System.out.println("COnnected !!!");
        } catch (ClassNotFoundException ce) {
            System.out.println("Driver not found : "+ce.getMessage());
        } catch (SQLException ex) {
            System.out.println("Error while connecting db : "+ex.getMessage());
        }  
    }
    
    @Override
    public List<User> getAllUsers() {
      ul = new ArrayList<>();
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM USER");
            while (rs.next()) {                
                u = new User();
                u.setId(rs.getInt(1));
                u.setName(rs.getString(2));
                u.setEmail(rs.getString(3));
                u.setPassword(rs.getString(4));
                u.setMovies(rs.getString(5));
                ul.add(u);
            }
        } catch (Exception e) {
            System.out.println("Error while loading data : "+e.getMessage());
        }
        return ul; 
    }

    @Override
    public User getUserByID(int id) {
        u = new User();
        try {
            ps =con.prepareStatement("SELECT * FROM USER where id  = ?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {                
                u.setId(rs.getInt(1));
                u.setName(rs.getString(2));
                u.setEmail(rs.getString(3));
                u.setPassword(rs.getString(4));
                u.setMovies(rs.getString(5));
            }
        } catch (SQLException ex) {
            System.out.println("Error while fetching user by id "+id+" : "+ex.getMessage());
        }
        return u;
    }

    @Override
    public User getUserByEmail(String em) {
        u = new User();
        try {
            ps =con.prepareStatement("SELECT * FROM USER where email  = ?");
            ps.setString(1, em);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {                
                u.setId(rs.getInt(1));
                u.setName(rs.getString(2));
                u.setEmail(rs.getString(3));
                u.setPassword(rs.getString(4));
                u.setMovies(rs.getString(5));
            }
        } catch (SQLException ex) {
            System.out.println("Error while fetching user by email "+em+" : "+ex.getMessage());
        } 
        return u;
    }

    @Override
    public boolean addUser(User u) {
        try {
            ps = con.prepareStatement("insert into user values (?,?,?,?,?)");
            ps.setInt(1, u.getId());
            ps.setString(2, u.getName());
            ps.setString(3, u.getEmail());
            ps.setString(4, u.getPassword());
            ps.setString(5, u.getMovies());
            int i = ps.executeUpdate();
            if (i != 0) {
                System.out.println("Inserted user ");
                return true;
            } else {
                System.out.println("Failed to insert");
                return false;
            }
        } catch (Exception e) {
            System.out.println("Failed to insert user :"+e.getMessage());
        }
        return false;
    }

    @Override
    public boolean deleteUser(User u) {
        try {
            ps = con.prepareStatement("delete from user where id = ?");
            ps.setInt(1, u.getId());
            int i = ps.executeUpdate();
            if (i != 0) {
                System.out.println("Deleted user ");
                return true;
            } else {
                System.out.println("Failed to delete");
                return false;
            }
        } catch (Exception e) {
            System.out.println("Failed to update user :"+e.getMessage());
        }
        
        return false;
    }

    @Override
    public boolean updateUser(User u) {
         try {
            ps = con.prepareStatement("update user set name = ?, email = ?, password = ? where id = ?");
            ps.setString(1, u.getName());
            ps.setString(2, u.getEmail());
            ps.setString(3, u.getPassword());
            ps.setInt(4, u.getId());
            int i = ps.executeUpdate();
            if (i != 0) {
                System.out.println("Updated user ");
                return true;
            } else {
                System.out.println("Failed to Update");
                return false;
            }
        } catch (Exception e) {
            System.out.println("Failed to update user :"+e.getMessage());
        }
        
        return false;
        
    }

    @Override
    public int getLastID() {
       int lid = 0;
        try {
            Statement st = con.createStatement();
            ResultSet rs= st.executeQuery("select max(id) from user");
            while (rs.next()) {                
                lid = rs.getInt(1);
            }
        } catch (Exception e) {
        }
 
        return lid;
    }
    
}
