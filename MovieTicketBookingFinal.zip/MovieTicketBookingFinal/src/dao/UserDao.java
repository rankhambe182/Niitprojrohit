package dao;

import java.util.List;
import model.User;

public interface UserDao {
    public List<User> getAllUsers();
    public User getUserByID(int id);
    public User getUserByEmail(String em);
    public boolean addUser(User u);
    public boolean deleteUser(User u);
    public boolean updateUser(User u);
    public int getLastID();
}
