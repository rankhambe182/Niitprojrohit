/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotel.management.systemm;
import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
/**
 *
 * @author ROHIT
 */
public class LoginRegistration extends JFrame implements ActionListener {
    
    JButton b1,b2,b3;
    Choice c1;
    JTextField t1,t2,t3,t4,t5;
    LoginRegistration()
    {
        JLabel l1=new JLabel("Check in details");
        l1.setFont(new Font("Tahoma",Font.PLAIN,20));
        l1.setForeground(Color.BLUE);
        l1.setBounds(90, 30, 200, 30);
        add(l1);
        
        
         JLabel l3=new JLabel("Username"); 
        l3.setBounds(30, 120, 100, 20);
        add(l3);
        
        t1 = new JTextField();
        t1.setBounds(200, 120, 150, 25);
        add(t1);
        
        
        
        
        JLabel l4=new JLabel("password"); 
        l4.setBounds(30, 160, 100, 20);
        add(l4);
        
        
         t2 = new JTextField();
        t2.setBounds(200, 160, 150, 25);
        add(t2);
        
          JLabel l5=new JLabel("Role"); 
        l5.setBounds(30, 200, 100, 20);
        add(l5);
        
        
         t3 = new JTextField();
        t3.setBounds(200, 200, 150, 25);
        add(t3);
        
        
        
          b1=new JButton("Submit");
        b1.setBackground(Color.black);
        b1.setForeground(Color.WHITE);
        b1.setBounds(30,250 ,100 ,20);
        b1.addActionListener(this);
        add(b1);
        
        
          b3=new JButton("Back");
        b3.setBackground(Color.black);
        b3.setForeground(Color.WHITE);
        b3.setBounds(200,250 ,150 ,25);
        b3.addActionListener(this);
        add(b3);
        
        
        
        
       
        
        
        
        
        
        getContentPane().setBackground(Color.WHITE);
        
        ImageIcon i1 =new ImageIcon(ClassLoader.getSystemResource("hotel/management/system/icons/nine.jpg"));
        JLabel l9=new JLabel(i1);
        l9.setBounds(400,50 ,500 ,300 );
          add(l9);
        
        
        setLayout(null);
        setBounds(500,200,1000,500);
        setVisible(true);
    }
    
    
    public void actionPerformed(ActionEvent ae)
    {
           conn c = new conn();
        if(ae.getSource()==b1)
        {
            try{
                
            
            String username=t1.getText();
            String password= t2.getText();
            String role=t3.getText();
            
            
            
                             if(role.contentEquals("customer"))
                             {
                                 
                            ResultSet rs = c.s.executeQuery("select * from login where username='"+username+"'");

                            int cnt=0;
                            while(rs.next()){
                                System.out.println("rs found--->");
                               cnt++;
                            }
                    if(cnt>0){
                        JOptionPane.showMessageDialog(null, "User already Exist!! Please try with different username"); 
                                 new LoginRegistration().setVisible(true);
                                 setVisible(false);
                    }else{
                    
                            String q1= "insert into login values('"+username+"','"+password+"','"+role+"')";
                          c.s.executeUpdate(q1);
                           JOptionPane.showMessageDialog(null, "Your data is succcessfully added!!");
                            new Login().setVisible(true);
                            setVisible(false);
                              } 
                             }
                             else
                              {
                                 JOptionPane.showMessageDialog(null, "your are entering invalid role please try again "); 
                                 new LoginRegistration().setVisible(true);
                                 setVisible(false);
                             }
                               
            }
            catch(SQLException e1){
                JOptionPane.showMessageDialog(null, "Please  valid details");
            }
        }
        else if (ae.getSource()==b2)
        {
            
        }
        else if (ae.getSource()==b3)
        {
            new Reception().setVisible(true);
            this.setVisible(false);
        }
    }
    
    public static void main(String[] args) {
        new LoginRegistration().setVisible(true);
        
    }
}
