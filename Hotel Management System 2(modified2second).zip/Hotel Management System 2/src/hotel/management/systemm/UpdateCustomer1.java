/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotel.management.systemm;
import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
/**
 *
 * @author ROHIT
 */
public class UpdateCustomer1 extends JFrame implements ActionListener {
    
    JButton b1,b2,b3;
    Choice c1;
    JTextField t1,t2,t3,t4,t5;
    UpdateCustomer1()
    {
        JLabel l1=new JLabel("Check in details");
        l1.setFont(new Font("Tahoma",Font.PLAIN,20));
        l1.setForeground(Color.BLUE);
        l1.setBounds(90, 30, 200, 30);
        add(l1);
        
         
        
        JLabel l2 = new JLabel("CUSTOMER ID:");
		l2.setBounds(30, 80, 100, 20);
                add(l2);
	      c1 = new Choice();
                try{
                    conn c = new conn();
                    ResultSet rs = c.s.executeQuery("select * from customer");
                    while(rs.next()){
                        c1.add(rs.getString("number"));    
                    }
                }catch(Exception e){ 
                
                }
                c1.setBounds(248, 85, 140, 20);
		add(c1);
        
        
       
         
        
         JLabel l3=new JLabel("Name"); 
        l3.setBounds(30, 120, 100, 20);
        add(l3);
        
        t1 = new JTextField();
        t1.setBounds(200, 120, 150, 25);
        add(t1);
        
        
        
        
        JLabel l4=new JLabel("Check-in"); 
        l4.setBounds(30, 160, 100, 20);
        add(l4);
        
        
         t2 = new JTextField();
        t2.setBounds(200, 160, 150, 25);
        add(t2);
        
       
        JLabel l5=new JLabel("Deposit"); 
        l5.setBounds(30, 200, 100, 20);
        add(l5);
        
        
         t3 = new JTextField();
        t3.setBounds(200, 200, 150, 25);
        add(t3);
        
        
        JLabel l6=new JLabel("Date of booking "); 
        l6.setBounds(30, 240, 100, 20);
        add(l6);
        
        
         t4 = new JTextField();
        t4.setBounds(200, 240, 150, 25);
        add(t4);
        
        
        b1=new JButton("Check");
        b1.setBackground(Color.black);
        b1.setForeground(Color.WHITE);
        b1.setBounds(30,340 ,100 ,30);
        b1.addActionListener(this);
        add(b1);
        
        
           b2=new JButton("Update");
        b2.setBackground(Color.black);
        b2.setForeground(Color.WHITE);
        b2.setBounds(150,340 ,100 ,30);
        b2.addActionListener(this);
        add(b2);
        
           b3=new JButton("Back");
        b3.setBackground(Color.black);
        b3.setForeground(Color.WHITE);
        b3.setBounds(270,340 ,100 ,30);
        b3.addActionListener(this);
        add(b3);
        
        
        getContentPane().setBackground(Color.WHITE);
        
        ImageIcon i1 =new ImageIcon(ClassLoader.getSystemResource("hotel/management/system/icons/nine.jpg"));
        JLabel l9=new JLabel(i1);
        l9.setBounds(400,50 ,500 ,300 );
          add(l9);
        
        
        setLayout(null);
        setBounds(500,200,1000,500);
        setVisible(true);
    }
    
    
    public void actionPerformed(ActionEvent ae)
    {
        
        conn c=new conn();
        if(ae.getSource()==b1)
        {
            
            try {
                String room=null;
                String deposit=null;
               int amountPaid;
                String price=null;
                
                String id=c1.getSelectedItem();
                System.out.println("id-->"+id);
                String str="select * from customer where  number = '"+id+"'";
                ResultSet rs=c.s.executeQuery(str);
                while(rs.next())
                {
                    //System.out.println("RS--->"+rs.getCursorName());
                    t1.setText(rs.getString("name"));
                    t2.setText(rs.getString("satus"));
                    t3.setText(rs.getString("deposit"));
                    t4.setText(rs.getString("dateOfBooking"));
 
                     
                }
                
                ResultSet rs2=c.s.executeQuery("select * from room where room_number='"+room+"'");
                while(rs2.next())
                {
                    price=rs2.getString("price");
                    amountPaid=Integer.parseInt(deposit)- Integer.parseInt(price);
                    t5.setText(Integer.toString(amountPaid));
                }
                
                    
            } catch (Exception e) {
                
               e.printStackTrace();
            }
        }
        else if (ae.getSource()==b2)
        {
            try{
             String id=c1.getSelectedItem();
             
            String name =t1.getText();
            String status=t2.getText();
            String deposit=t3.getText();
            String dateOfBooking=t4.getText();
            System.out.println("id--->"+id);
            
            
           String updQuery = "update customer set name='"+name+"',"
                    + " satus='"+status+"',"
                            + "deposit='"+deposit+"',"
                                    + " dateOfBooking='"+dateOfBooking+"' where number='"+id+"'  ";
                System.out.println("upd query"+updQuery);
           int affRows= c.s.executeUpdate(updQuery);
           //c.s.execu
            
            System.out.println("aff Rows are:"+affRows);
            JOptionPane.showMessageDialog(null, " Customer Details Updated Successfully ");
            }catch(Exception ex){
                ex.printStackTrace();
            }
            
        }
        else if (ae.getSource()==b3)
        {
            new Reception().setVisible(true);
            this.setVisible(false);
        }
    }
    
    public static void main(String[] args) {
        new UpdateCustomer1().setVisible(true);
        
    }
}
