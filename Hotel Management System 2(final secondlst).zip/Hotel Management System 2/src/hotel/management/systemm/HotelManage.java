/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotel.management.systemm;

import javax.swing.*;


/**
 *
 * @author ROHIT
 */
public class HotelManage extends JFrame{

  HotelManage() {
      setBounds(300, 300, 540, 360);
     //   setSize(400,400);
       
       // setLocation(300,300);
       ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("src/hotel/management/system/loginpage.jpg"));
       JLabel l1=new JLabel(i1);
       l1.setBounds(300,300, 540, 360);
       add(l1);
       
       
       setLayout(null);
        setVisible(true);
       
    }
    
    
    
    
    
    public static void main(String[] args) {
        new HotelManage();
        
    }
}
