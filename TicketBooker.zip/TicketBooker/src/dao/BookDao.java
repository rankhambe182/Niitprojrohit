/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.awt.print.Book;
import java.util.List;
import model.Booker;

/**
 *
 * @author ROHIT
 */
public interface BookDao {
     public List<Booker> getAllBookers();
    public Booker getBookerByID(int id);
    public Booker getBookerByEmail(String em);
    public boolean addBooker(Booker b);
    public boolean deleteBooker(Booker b);
    public boolean updateBooker(Booker b);
    public int getLastID();
   
}
