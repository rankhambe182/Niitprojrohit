/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author ROHIT
 */
public class Booker {
   private int id;
    private String name , email, gender,time,arrang;

    public Booker() {
    }

    public Booker(int id, String name, String email, String gender, String time, String arrang) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.gender = gender;
        this.time = time;
        this.arrang = arrang;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getArrang() {
        return arrang;
    }

    public void setArrang(String arrang) {
        this.arrang = arrang;
    }

    @Override
    public String toString() {
        return "Booker{" + "id=" + id + ", name=" + name + ", email=" + email + ", gender=" + gender + ", time=" + time + ", arrang=" + arrang + '}';
    }

   
    
   

    
  
  
    
    
}
