/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import daoimpl.BookDaoImpl;
import java.util.List;
import model.Booker;

/**
 *
 * @author ROHIT
 */
public class TestMain {
    public static void main(String[] args) {
        BookDaoImpl bdi=new BookDaoImpl();
        //  List<Booker> bl = bdi.getAllBookers();
    //   for (Booker b : bl) {
     //       System.out.println("====== "+b.getId()+" ========");
      //     System.out.println("Name : "+b.getEmail());
     //  }
   

      
    }
}
