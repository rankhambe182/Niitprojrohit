/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoimpl;

import dao.BookDao;
import java.awt.print.Book;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Booker;

/**
 *
 * @author ROHIT
 */
public class BookDaoImpl implements BookDao{

     List<Booker> bl;
    Booker b;
    Connection con;
    PreparedStatement ps;
    
    
    public BookDaoImpl() {
         try {
            Class.forName("org.h2.Driver");
            con = DriverManager.getConnection("jdbc:h2:~/test", "sa", "pass");
            System.out.println("COnnected !!!");
        } catch (ClassNotFoundException ce) {
            System.out.println("Driver not found : "+ce.getMessage());
        } catch (SQLException ex) {
            System.out.println("Error while connecting db : "+ex.getMessage());
        }  
        
       
        
    }

    
    
    
    
    
    
    @Override
    public List<Booker> getAllBookers() {
        bl = new ArrayList<>();
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM USER");
            while (rs.next()) {                
               b = new Booker();
               b.setId(rs.getInt(1));
               b.setName(rs.getString(2));
               b.setEmail(rs.getString(3));
               b.setGender(rs.getString(4));
               b.setTime(rs.getString(5));
            
               bl.add(b);
            }
        } catch (Exception e) {
            System.out.println("Error while loading data : "+e.getMessage());
        }
        return bl;
    }

    @Override
    public Booker getBookerByID(int id) {
         //To change body of generated methods, choose Tools | Templates.
         b = new Booker();
        try {
            ps =con.prepareStatement("SELECT * FROM USER where id  = ?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {                
                b.setId(rs.getInt(1));
                b.setName(rs.getString(2));
                b.setEmail(rs.getString(3));
                b.setGender(rs.getString(4));
                b.setTime(rs.getString(5));
            
            }
        } catch (SQLException ex) {
            System.out.println("Error while fetching user by id "+id+" : "+ex.getMessage());
        }
        return b;
    }

    @Override
    public Booker getBookerByEmail(String em) {
        b = new Booker();
        try {
            ps =con.prepareStatement("SELECT * FROM USER where email  = ?");
            ps.setString(1, em);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {                
                b.setId(rs.getInt(1));
                b.setName(rs.getString(2));
                b.setEmail(rs.getString(3));
                b.setGender(rs.getString(4));
                b.setTime(rs.getString(5));
               
            }
        } catch (SQLException ex) {
            System.out.println("Error while fetching user by email "+em+" : "+ex.getMessage());
        } 
        return b ;
    }

    @Override
    public boolean addBooker(Booker b) {
          try {
            ps = con.prepareStatement("insert into BOOKER values (?,?,?,?,?,?)");
            ps.setInt(1, b.getId());
            ps.setString(2, b.getName());
            ps.setString(3, b.getEmail());
            ps.setString(4, b.getGender());
            ps.setString(5, b.getTime());
           ps.setString(6, b.getArrang());
        
            int i = ps.executeUpdate();
            if (i != 0) {
                System.out.println("Inserted user ");
                return true;
            } else {
                System.out.println("Failed to insert");
                return false;
            }
        } catch (Exception e) {
            System.out.println("Failed to insert user :"+e.getMessage());
        }
        return false;
    }

    @Override
    public boolean deleteBooker(Booker b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean updateBooker(Booker b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getLastID() {
        int lid = 0;
        try {
            Statement st = con.createStatement();
            ResultSet rs= st.executeQuery("select max(id) from Booker");
            while (rs.next()) {                
                lid = rs.getInt(1);
            }
        } catch (Exception e) {
        }
 
        return lid;
    }
    }

    
    
   

