/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotel.management.systemm;

import javax.swing.JFrame;
import java.awt.EventQueue;


import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
/**
 *
 * @author ROHIT
 */
public class DeleteEmployee1 extends JFrame implements ActionListener {
    
    JButton b1,b2,b3;
    Choice c1;
    JTextField t1,t2,t3,t4,t5;
    JTextField textField,textField_1,textField_2,textField_3,textField_4,textField_5,textField_6;
        
        
         DeleteEmployee1(){
              
     JLabel l1=new JLabel("Delete Employee");
        l1.setFont(new Font("Tahoma",Font.PLAIN,20));
        l1.setForeground(Color.BLUE);
        l1.setBounds(90, 30, 200, 30);
        add(l1);
        
        
       JLabel l2 = new JLabel("CUSTOMER ID:");
		l2.setBounds(30, 80, 100, 20);
                add(l2);
                
                
	   c1 = new Choice();
                try{
                    conn c = new conn();
                    ResultSet rs = c.s.executeQuery("select * from customer");
                    while(rs.next()){
                        c1.add(rs.getString("number"));    
                    }
                }catch(Exception e){ 
                
                }
                c1.setBounds(248, 85, 140, 20);
		add(c1);
        
         
      b1=new JButton("Delete");
        b1.setBackground(Color.WHITE);
        b1.setForeground(Color.BLACK);
        b1.setBounds(30,340 ,100 ,30);
        b1.addActionListener(this);
        add(b1);
        
        
       
         }

    @Override
    public void actionPerformed(ActionEvent e) {
       
        if(e.getSource()==b1)
       {
           
       
        JLabel l2 = new JLabel("CUSTOMER ID:");
        l2.setBackground(Color.BLACK);
		l2.setBounds(30, 80, 100, 20);
                add(l2);
	     // c1 = new Choice();
                try{
                    
                    conn c = new conn();
                    String id=c1.getSelectedItem();
                    System.out.println("id"+id);
                //String selstr="select * from customer where  number = '"+id+"'";
                String str="delete from customer where  number = '"+id+"'";
              // ResultSet rs=c.s.executeQuery(selstr);
               int  result= c.s.executeUpdate(str);
               System.out.println("deleted rows:"+result);
                  //  ResultSet rs = c.s.executeQuery("delete from customer where id = '"+c1.getSelectedItem()+"'");
                  
                }catch(Exception ex){ 
                   ex.printStackTrace();
                }
                c1.setBounds(248, 85, 140, 20);
              add(c1);
                
                
                b1=new JButton("Delete");
            b1.setBackground(Color.BLACK);
                  b1.setForeground(Color.WHITE);
                 b1.setBounds(30,340 ,100 ,30);
                b1.addActionListener(this);
              add(b1);
        
                
             
         }
        
        
        
        
        
    }
    public static void main(String[] args) {
            new DeleteEmployee1().setVisible(true);
    }
        }
